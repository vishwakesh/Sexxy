import { type EmailAccount, type InsertEmailAccount, type Email, type InsertEmail, type Domain, type User, type InsertUser } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";

const MemoryStore = createMemoryStore(session);
const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getEmailAccounts(userId: number): Promise<EmailAccount[]>;
  createEmailAccount(userId: number, account: InsertEmailAccount): Promise<EmailAccount>;
  deleteEmailAccount(id: number, userId: number): Promise<void>;
  getEmails(accountId: number, userId: number): Promise<Email[]>;
  createEmail(email: InsertEmail): Promise<Email>;
  getDomains(): Promise<Domain[]>;
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private emailAccounts: Map<number, EmailAccount>;
  private emails: Map<number, Email>;
  private domains: Domain[];
  private currentUserId: number;
  private currentAccountId: number;
  private currentEmailId: number;
  sessionStore: session.Store;
  private emailPasswords: Map<number, string>;

  constructor() {
    this.users = new Map();
    this.emailAccounts = new Map();
    this.emails = new Map();
    this.emailPasswords = new Map();
    this.currentUserId = 1;
    this.currentAccountId = 1;
    this.currentEmailId = 1;
    this.domains = [
      { id: 1, name: "freemail.com", available: true },
      { id: 2, name: "webbox.net", available: true },
      { id: 3, name: "quickmail.org", available: true },
      { id: 4, name: "mailstack.io", available: true },
    ];
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const newUser: User = {
      ...user,
      id,
      createdAt: new Date(),
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async getEmailAccounts(userId: number): Promise<EmailAccount[]> {
    return Array.from(this.emailAccounts.values()).filter(
      (account) => account.userId === userId
    );
  }

  async createEmailAccount(userId: number, account: InsertEmailAccount): Promise<EmailAccount> {
    const userAccounts = await this.getEmailAccounts(userId);
    if (userAccounts.length >= 50) {
      throw new Error("Maximum number of email accounts (50) reached");
    }

    const id = this.currentAccountId++;
    const { password, ...accountData } = account;

    // Hash the email account password
    const hashedPassword = await hashPassword(password);
    this.emailPasswords.set(id, hashedPassword);

    const newAccount: EmailAccount = {
      ...accountData,
      id,
      userId,
      isActive: true,
      createdAt: new Date(),
    };

    this.emailAccounts.set(id, newAccount);
    return newAccount;
  }

  async deleteEmailAccount(id: number, userId: number): Promise<void> {
    const account = this.emailAccounts.get(id);
    if (account && account.userId === userId) {
      this.emailAccounts.delete(id);
      this.emailPasswords.delete(id);
    }
  }

  async getEmails(accountId: number, userId: number): Promise<Email[]> {
    const account = Array.from(this.emailAccounts.values()).find(
      (acc) => acc.id === accountId && acc.userId === userId
    );
    if (!account) return [];

    return Array.from(this.emails.values()).filter(
      (email) => email.accountId === accountId
    );
  }

  async createEmail(email: InsertEmail): Promise<Email> {
    const id = this.currentEmailId++;
    const newEmail: Email = {
      ...email,
      id,
      read: false,
      createdAt: new Date(),
    };
    this.emails.set(id, newEmail);
    return newEmail;
  }

  async getDomains(): Promise<Domain[]> {
    return this.domains;
  }
}

export const storage = new MemStorage();
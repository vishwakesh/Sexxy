import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { EmailAccount, Email } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Mail } from "lucide-react";

interface InboxViewProps {
  account: EmailAccount;
}

export function InboxView({ account }: InboxViewProps) {
  const { data: emails, isLoading } = useQuery<Email[]>({
    queryKey: [`/api/emails/${account.id}`],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading Inbox...</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Inbox - {account.address}@{account.domain}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!emails?.length ? (
          <div className="text-center text-muted-foreground py-8">
            <Mail className="mx-auto h-12 w-12 mb-4 text-muted-foreground/50" />
            <p>No messages yet</p>
          </div>
        ) : (
          emails.map((email) => (
            <div
              key={email.id}
              className={`p-4 rounded-lg border ${
                email.read ? "bg-background" : "bg-primary/5"
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <p className="font-medium">{email.from}</p>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(email.createdAt), "MMM d, h:mm a")}
                </p>
              </div>
              <p className="font-medium mb-1">{email.subject}</p>
              <p className="text-sm text-muted-foreground line-clamp-2">
                {email.content}
              </p>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

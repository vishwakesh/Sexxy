import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import type { Domain } from "@shared/schema";

interface DomainSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

export function DomainSelector({ value, onChange }: DomainSelectorProps) {
  const { data: domains, isLoading } = useQuery<Domain[]>({
    queryKey: ["/api/domains"],
  });

  return (
    <Select value={value} onValueChange={onChange} disabled={isLoading}>
      <SelectTrigger>
        <SelectValue placeholder="Select a domain" />
      </SelectTrigger>
      <SelectContent>
        {domains?.map((domain) => (
          <SelectItem
            key={domain.id}
            value={domain.name}
            disabled={!domain.available}
          >
            @{domain.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

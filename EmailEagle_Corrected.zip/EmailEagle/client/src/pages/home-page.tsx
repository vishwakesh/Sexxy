import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { EmailAccounts } from "@/components/email-accounts";
import { InboxView } from "@/components/inbox-view";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { LogOut, Plus } from "lucide-react";
import type { EmailAccount } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

export default function HomePage() {
  const [selectedAccount, setSelectedAccount] = useState<EmailAccount | null>(null);
  const { user, logoutMutation } = useAuth();
  const { data: accounts, isLoading } = useQuery({
    queryKey: ["/api/email-accounts"],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold">Email Dashboard</h1>
            <p className="text-muted-foreground">Welcome back, {user?.username}</p>
          </div>
          <div className="flex gap-4">
            <Link href="/create">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Email Account
              </Button>
            </Link>
            <Button
              variant="outline"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4">
            <EmailAccounts
              accounts={accounts || []}
              isLoading={isLoading}
              selectedAccount={selectedAccount}
              onSelectAccount={setSelectedAccount}
            />
          </div>
          <div className="lg:col-span-8">
            {selectedAccount ? (
              <InboxView account={selectedAccount} />
            ) : (
              <div className="bg-card p-8 rounded-lg text-center text-muted-foreground">
                Select an email account to view messages
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}